package com.cg.eba.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Date;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.cg.eba.bean.BillDetails;
import com.cg.eba.bean.Consumer;
import com.cg.eba.exception.BillException;
import com.cg.eba.service.BillServiceImpl;
import com.cg.eba.service.IBillService;


@WebServlet(urlPatterns ={"/Home","/list","/checkConsumer","/showBillDetails","/CalulateBill"})
public class BillController extends HttpServlet 
{
	private static final long serialVersionUID = 1L;
   IBillService billService;
   Consumer cons = new Consumer();
   BillDetails bill = new BillDetails();
   int FixedCharge = 100;
   
    public BillController()
    {
        super();
      
    }

	public void init(ServletConfig config) throws ServletException
	{
	
	}

	
	public void destroy()
	{
	
	}

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		doPost(request, response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		String path = request.getServletPath();
		String url ="";
		PrintWriter out = response.getWriter();
		HttpSession session;
		billService = new BillServiceImpl();
		try
		{
			switch (path)
			{
			case "/Home":
				RequestDispatcher rd = request.getRequestDispatcher("/Index.jsp");
				rd.forward(request, response);
				//url="Index.jsp";
			break;
			
			case "/list":
				System.out.println(path);
				List<Consumer> clist = billService.getAllConsumers();
				request.setAttribute("cList", clist);
				RequestDispatcher rdList = request.getRequestDispatcher("/ListOfConsumer.jsp");
				rdList.forward(request, response);
			break;
			case "/checkConsumer":
				String consNum = request.getParameter("cname");
				int cnum = Integer.parseInt(consNum);
				request.setAttribute("ConsID", consNum);
				boolean check = billService.isConsumerExist(cnum);
				if(check)
				{
					Consumer consumer = billService.getConsumer(cnum);
					request.setAttribute("Consumer", consumer);
					RequestDispatcher rdExist = request.getRequestDispatcher("/Show_Consumer.jsp");
					rdExist.forward(request, response);
				}
				else
				{
					out.println("<h3 style ='color:red'>Entered Consumer Id Doesn't Exist.</h3>");
				}
				break;
				
			case "/showBillDetails":
				int consID = Integer.parseInt(request.getParameter("consNo"));
				Consumer cons = new Consumer();
				List<BillDetails> bList =  billService.getBillDetails(consID);
				request.setAttribute("conNum", consID);
				request.setAttribute("BillInfo", bList);
				System.out.println(bList);
				RequestDispatcher rdShow = request.getRequestDispatcher("/ShowBillInfo.jsp");
				rdShow.forward(request, response);
				break;
				
			case "/CalulateBill":
				String c =  (String) request.getParameter("txtCnum");
				String LM = (String) request.getParameter("txtLMmeterReading");
				String CM = (String) request.getParameter("txtCMmeterReading");
				int consumerNum = Integer.parseInt(c);
				int lM = Integer.parseInt(LM);
				int cM = Integer.parseInt(CM);
				System.out.println("Calculation");
				if(cM > lM)
				{
					int units = (cM -lM);
					double netAmt = (units * 1.15 + FixedCharge);
					bill = new BillDetails();
					bill.setConsumer_num(consumerNum);
					bill.setCur_Reading(cM);
					bill.setUnit_consumed(units);
					bill.setNetAmt(netAmt);
					Long millis = System.currentTimeMillis() ;
					java.sql.Date date = new Date(millis) ;
					bill.setBill_date(date);
					
					Consumer consum = billService.getConsumer(consumerNum);
					BillDetails	bills = billService.insertBill(bill);
					request.setAttribute("Consumer", consum);
					request.setAttribute("bill", bills);
					System.out.println(bills);
					RequestDispatcher rdCal = request.getRequestDispatcher("/View.jsp");
					rdCal.forward(request, response);
				}
				break;
			}
		}
				
		catch(Exception e)
				
		{
			request.setAttribute("error", e.getMessage());
			url="Error.jsp";
				
		}
	

		}
	}


