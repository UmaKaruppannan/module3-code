package com.cg.eba.service;

import java.sql.SQLException;



import java.util.List;

import com.cg.eba.bean.BillDetails;
import com.cg.eba.bean.Consumer;
import com.cg.eba.dao.BillDAOImpl;
import com.cg.eba.dao.IBillDAO;
import com.cg.eba.exception.BillException;

public class BillServiceImpl implements IBillService
{
	private IBillDAO billDAO;
	
	

	public BillServiceImpl() 
	{
		billDAO = new BillDAOImpl();

	}
	@Override
	public BillDetails insertBill(BillDetails bill) throws BillException {
		// TODO Auto-generated method stub
		return billDAO.insertBill(bill);
	}
	@Override
	public Consumer getConsumer(int id) throws BillException {
		// TODO Auto-generated method stub
		return billDAO.getConsumer(id);
	}
	@Override
	public boolean isConsumerExist(int id) throws BillException {
		// TODO Auto-generated method stub
		return billDAO.isConsumerExist(id);
	}
	@Override
	public List<Consumer> getAllConsumers() throws BillException {
		// TODO Auto-generated method stub
		return billDAO.getAllConsumers();
	}
	@Override
	public List<BillDetails> getBillDetails(int consid) throws BillException {
		// TODO Auto-generated method stub
		return billDAO.getBillDetails(consid);
	}

}
