package com.cg.eba.dao;



import java.sql.SQLException;
import java.util.List;

import com.cg.eba.bean.BillDetails;
import com.cg.eba.bean.Consumer;
import com.cg.eba.exception.BillException;

public interface IBillDAO 
{
	public BillDetails insertBill(BillDetails bill) throws BillException;
	
	public Consumer getConsumer(int id) throws BillException;
	
	public boolean isConsumerExist(int id) throws BillException;
	
	List<Consumer> getAllConsumers() throws BillException;
	
	List<BillDetails> getBillDetails(int consid) throws BillException;
}
