package com.cg.eba.dao;

import java.sql.Statement;


import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Date;
import java.util.ArrayList;
import java.util.List;

import com.cg.eba.bean.BillDetails;
import com.cg.eba.bean.Consumer;
import com.cg.eba.exception.BillException;
import com.cg.eba.util.DBUtil;


public class BillDAOImpl implements IBillDAO
{
	Connection con;
	
	Statement stm;
	ResultSet res;
	PreparedStatement pstm;
	Consumer cons =null;
	BillDetails bill = null;
	@Override
	public BillDetails insertBill(BillDetails bill) throws BillException
	{
		try
		{
		con=DBUtil.getConnection();
		stm = con.createStatement();
		res = stm.executeQuery("select seq_bill_num.nextval from dual");
		if(res.next()==false)	
		{
			System.out.println("something went wrong while generating id");
		}
		
		int billNum = res.getInt(1);
		int cons_num = bill.getConsumer_num();
		int cur_read = bill.getCur_Reading();
		int unit_con = bill.getUnit_consumed();
		double amount = bill.getNetAmt();
		Date bill_date = bill.getBill_date();
		
		String insertQuery = "insert into billdetails values (?,?,?,?,?,?)";
		int dataInserted = 0;
		
		
			//pstm.executeQuery(insertQuery);
			pstm = con.prepareStatement(insertQuery);
			pstm.setInt(1, billNum);
			pstm.setInt(2, cons_num);
			pstm.setInt(3, cur_read);
			pstm.setInt(4, unit_con);
			pstm.setDouble(5, amount);
			pstm.setDate(6, bill_date);
			pstm.executeQuery();
			//dataInserted=pstm.executeUpdate();
			
		}
		catch(SQLException e)
		{
			throw new BillException("");
		}
		finally
		{
			try
			{
				con.close();
				pstm.close();
			}
			catch (SQLException e) 
			{
				e.printStackTrace();
			}
			
		}
		return bill;

    }
	@Override
	public Consumer getConsumer(int id) throws BillException 
	{
		
		
		try
		{
			con= DBUtil.getConnection();
			String selectQuery = "select * from consumers where Consumer_num = ?";
			pstm = con.prepareStatement(selectQuery);
			pstm.setInt(1, id);
			res=pstm.executeQuery();
			res.next();
			cons = new Consumer();
			cons.setConsNum(res.getInt(1));
			cons.setName(res.getString(2));
			cons.setAddress(res.getString(3));
			
		}
		catch(SQLException e)
		{
			throw new BillException("Problem while fetching data"+e.getMessage());
		}
		finally
		{
			try 
			{
				con.close();
				res.close();
				pstm.close();
			} 
			catch (Exception e) 
			{
				e.printStackTrace();
			}
			
		}
		return cons;
	}
	@Override
	public boolean isConsumerExist(int id) throws BillException 
	{
		
		boolean flag = false;
		
		
		try
		{
			con= DBUtil.getConnection();
			String selectQuery = "select count(*) from consumers where consumer_num =?";
			pstm = con.prepareStatement(selectQuery);
			pstm.setInt(1, id);
			res=pstm.executeQuery();
			res.next();
			int count = res.getInt(1);			
			if(count == 1)
			{
				flag = true;
			}
			else
			{
				
				flag = false;
			}
				
		} 
		catch (SQLException e) 
		{
			throw new BillException("Invalid Consumer ID :"+e.getMessage());
		}
		finally
		{
			try 
			{
				
				res.close();
				pstm.close();
				con.close();
			} 
			catch (Exception e) 
			{
				e.printStackTrace();
			}
			
		}
		
		return flag;
	}
	@Override
	public List<Consumer> getAllConsumers() throws BillException {
		List<Consumer> cList = new ArrayList<Consumer>();
		try
		{
			 con= DBUtil.getConnection();
			 stm = con.createStatement();
			 res = stm.executeQuery("select * from Consumers");
			while(res.next())
			{
				Consumer cons = new Consumer();
				cons.setConsNum(res.getInt(1));
				cons.setName(res.getString(2));
				cons.setAddress(res.getString(3));
				cList.add(cons);
			}
		}
		catch(SQLException e)
		{
			throw new BillException("Problem while fetching  all Consumers data"+e.getMessage());
		}
		finally
		{
			try 
			{
				con.close();
				res.close();
				
			} 
			catch (Exception e) 
			{
				e.printStackTrace();
			}
			
		}
		return cList;
	}
	@Override
	public List<BillDetails> getBillDetails(int consid) throws BillException
	{
	
		List<BillDetails> bList =new ArrayList<BillDetails>();
		String selectQuery = "select * from billdetails where consumer_num=?";
		try
		{
			con=DBUtil.getConnection();
			pstm = con.prepareStatement(selectQuery);
			pstm.setInt(1, consid);
			res=pstm.executeQuery();
			
			while(res.next())
			{
				bill = new BillDetails();
				bill.setBillNum(res.getInt(1));
				bill.setConsumer_num(res.getInt(2));
				bill.setCur_Reading(res.getInt(3));
				bill.setUnit_consumed(res.getInt(4));
				bill.setNetAmt(res.getDouble(5));
				bill.setBill_date(res.getDate(6));
				bList.add(bill);
			}
		}
		catch(SQLException e)
		{
			throw new BillException("Problem while fetching  all Bill details of Consumer : "+consid+" \n"+e.getMessage());
		}
		finally
		{
			try 
			{
				res.close();
				con.close();
				
				
			} 
			catch (Exception e) 
			{
				e.printStackTrace();
			}
			
		}
		
		return bList;
	}
}
