package com.cg.eba.bean;

import java.sql.Date;



public class BillDetails 
{
	private int billNum;
	private int consumer_num;
	private int cur_Reading;
	private int unit_consumed;
	private double netAmt;
	private Date bill_date;
	public int getBillNum() {
		return billNum;
	}
	public void setBillNum(int billNum) {
		this.billNum = billNum;
	}
	public int getConsumer_num() {
		return consumer_num;
	}
	public void setConsumer_num(int consumer_num) {
		this.consumer_num = consumer_num;
	}
	public int getCur_Reading() {
		return cur_Reading;
	}
	public void setCur_Reading(int cur_Reading) {
		this.cur_Reading = cur_Reading;
	}
	public int getUnit_consumed() {
		return unit_consumed;
	}
	public void setUnit_consumed(int unit_consumed) {
		this.unit_consumed = unit_consumed;
	}
	public double getNetAmt() {
		return netAmt;
	}
	public void setNetAmt(double netAmt) {
		this.netAmt = netAmt;
	}
	public Date getBill_date() {
		return bill_date;
	}
	public void setBill_date(Date bill_date) {
		this.bill_date = bill_date;
	}
	
	public BillDetails(int billNum, int consumer_num, int cur_Reading,
			int unit_consumed, int netAmt, Date bill_date) {
		super();
		this.billNum = billNum;
		this.consumer_num = consumer_num;
		this.cur_Reading = cur_Reading;
		this.unit_consumed = unit_consumed;
		this.netAmt = netAmt;
		this.bill_date = bill_date;
	}
	public BillDetails() {
		super();
	}
	
	
	
}
