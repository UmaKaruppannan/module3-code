package com.cg.eba.bean;

public class Consumer 
{
	private int consNum;
	private String name;
	private String address;
	public int getConsNum() {
		return consNum;
	}
	public void setConsNum(int consNum) {
		this.consNum = consNum;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	
	public Consumer(int consNum, String name, String address) {
		super();
		this.consNum = consNum;
		this.name = name;
		this.address = address;
	}
	
	public Consumer() {
		super();
	}
	
	
	

}
