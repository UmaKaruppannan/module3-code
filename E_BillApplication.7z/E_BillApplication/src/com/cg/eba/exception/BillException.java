package com.cg.eba.exception;

public class BillException extends Exception
{
	public BillException()
	{
		
	}
	public BillException(String message)
	{
		super(message);
	}
	
}
